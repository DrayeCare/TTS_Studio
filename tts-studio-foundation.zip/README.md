# TTS Studio

> A Python-powered desktop game-show controller for live TTS gameplay.

TTS Studio is an offline-first desktop application for running live quiz and word-game sessions. It provides an operator console and a separate audience-facing stage display, controlled from one computer.

## Goals
- Operate a game from a single desktop application.
- Support operator and stage windows across two monitors.
- Reveal questions and answers at the operator's discretion.
- Manage teams and scores.
- Load question sets from JSON.
- Remain usable offline and recover gracefully from display issues.

## V1 Scope
- Operator console and stage display windows.
- Monitor selection and fullscreen display.
- Question set loading from JSON.
- Select, show, hide, and reveal question/answer.
- Teams and score adjustment.
- Session reset and basic state persistence.

Out of scope for V1: networked buzzers, remote clients, OBS integration, online services, and a full question editor.

## Architecture
The UI must not own the authoritative game state. All state-changing commands pass through `GameController`; the stage display renders state snapshots.

```text
Operator UI ──commands──> GameController ──> GameState
                                      ├──> QuestionService
                                      ├──> ScoreEngine
                                      └──> StageDisplay
```

## Technology
- Python 3.11+
- PySide6 / Qt Widgets
- JSON data
- pytest (testing)
- PyInstaller (packaging, planned)

## Setup
```bash
python -m venv .venv
```

Windows:
```bash
.venv\\Scripts\\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
```

Run:
```bash
python main.py
```

## Question Format
See `data/questions/sample_questions.json`.

## Project Layout
```text
tts-studio/
├── main.py
├── app/
├── core/
├── models/
├── services/
├── ui/
├── data/questions/
├── assets/
└── tests/
```

## Roadmap
- [ ] Foundation: application entry, theme, dual windows, screen detection
- [ ] Game state and controller
- [ ] Question selection and reveal flow
- [ ] Team scoring
- [ ] Stage display polish
- [ ] Session persistence
- [ ] Audio and animation
- [ ] Question editor
- [ ] Packaging

## Live-show safety
- Destructive actions require confirmation.
- Operator shortcuts should not trigger destructive actions accidentally.
- Stage window must offer a fallback if the second monitor is unavailable.
- Keep UI responsive; long-running tasks must not block the UI thread.
- Validate imported question data.

## License
TBD.

## Status
Planning / foundation scaffold.
